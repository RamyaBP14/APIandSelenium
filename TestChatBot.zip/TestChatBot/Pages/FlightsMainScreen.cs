﻿using AventStack.ExtentReports;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TestChatBot.Pages
{
   public class FlightsMainScreen : BaseClass
    {
        #region Locators
        private IWebElement mainwindow => driver.FindElement(By.Id("avm_chat_window_444588bc-92fe-477f-87c1-88a92946346a"));
        private IWebElement welcomeText => driver.FindElement(By.XPath("//*[@class = 'conversation-item clearfix not-mine']//div[@class ='default_card_description']"));
        

        #endregion

        #region Action Methods
        
        public string GetWelcomeText(ExtentTest log)
        {
            //welcomeText.WaitUntillControlExists();
            return welcomeText.GetTextFromControl(log);
        }
        public void NavigateToURL(string url)
        {
            driver.Navigate().GoToUrl(url);            
            driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(7);
            driver.Manage().Window.Maximize();
        }
        public void ChooseFlight(string extectedflight, ExtentTest log)
        {
            var table = driver.FindElements(By.XPath("//table/tbody/tr"));

            for (int i = 1; i < table.Count; i++)
            {
                if (driver.FindElement(By.XPath("//table/tbody/tr[" + i + "]/td[3]")).Text == extectedflight)
                {
                    driver.FindElement(By.XPath("//table/tbody/tr[" + i + "]/td[1]/input")).Click();
                    break;
                }
            }

        }

              
      
        #endregion
    }
}
