﻿using AventStack.ExtentReports;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
namespace TestChatBot
{
   public static class GenericLib
    {
        
        public static void SelectFromComboBox(this IWebElement element, string value, ExtentTest log)
        {
            SelectElement select = new SelectElement(element);
            select.SelectByText(value);

        }
        public static void Click(this IWebElement element, ExtentTest log)
        {
            try
            {
                element.Click();
              //  element.GetAttribute("Name").ToString()
                log.Info("Successfully clicked on the element");
            }
            catch (Exception ex)
            {
                log.Error("Error while clicking on element either element not exists or not enabled" + ex.Message);
            }
        }
        public static string GetEnumDescription(this Enum value)
        {
            var enumValue = value.GetType().GetMember(value.ToString()).First()?
                .GetCustomAttribute<DescriptionAttribute>()?.Description;
            return (enumValue != null && enumValue.Length > 0) ? enumValue.ToString() : value.ToString();
        }

        public static void EnterText(this IWebElement element, string desc, ExtentTest log)
        {
            var controlName = element.GetAttribute("Name") ?? element.GetAttribute("AutomationId");
            try
            {
                element.Click();
                element.SendKeys(desc);
                log.Info("Successfully Entered value to " + controlName + " element");
            }
            catch (Exception ex)
            {
                log.Error("Error while setting value to " + controlName + ex.Message);
            }
        }

        /// <summary>
        /// Returns Checked status of check box/Radio
        /// </summary>
        /// <param name="element"></param>
        /// <param name="log"></param>
        /// <returns></returns>
        public static bool IsSelected(this IWebElement element, ExtentTest log)
        {
            bool checkedStatus = false;
            try
            {
                checkedStatus = element.Selected;
            }
            catch (Exception ex)
            {
                checkedStatus = false;
                log.Error("Error while getting Checkbox checked status" + ex.Message);
            }
            return checkedStatus;
        }

        /// <summary>
        /// Returns value from controls
        /// </summary>
        /// <param name="element"></param>
        /// <param name="log"></param>
        /// <returns></returns>
        public static string GetTextFromControl(this IWebElement element, ExtentTest log)
        {
            string Value = string.Empty;
            try
            {
                if (element.Displayed)
                {
                    Value = element.Text;
                    //log.Info("Successfully getting value from " + element.GetAttribute("Name").ToString() + " element ");
                    log.Info("Successfully getting value from the element");
                }
                //else
                //    log.Error("Unable to Get value from " + element.GetAttribute("Name").ToString() + ".element does not exists on UI");
            }
            catch (Exception ex)
            {
                log.Error("Error while getting value to " + element.GetAttribute("Name").ToString() + ex.Message);
            }
            return Value;
        }

        public static void LogVerificationResult(this ExtentTest Report, String verificationName, String expected, String actual, bool ignoreCase = false)
        {
           if (String.Compare(expected, actual, ignoreCase) != 0)
            {
                Report.Log(Status.Fail, verificationName + " Expected value is : " + "<b>" + expected + "</b>" + " and Actual value is : " + "<b>" + actual + "</b>");
                
            }
            else
            {
                Report.Log(Status.Pass, verificationName + " Expected value is : " + "<b>" + expected + "</b>" + " and Actual value is : " + "<b>" + actual + "</b>");
            }
        }

        public static void WaitUntillControlExists(this IWebElement element)
        {
            WebDriverWait wait = new WebDriverWait(BaseClass.driver, TimeSpan.FromSeconds(30));
            wait.Until(driver => element);
        }
    }
}
