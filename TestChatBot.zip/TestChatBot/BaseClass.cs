﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using WebDriverManager.DriverConfigs.Impl;

namespace TestChatBot
{
   public class BaseClass
    {
        public static IWebDriver driver;
        string resultPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
        public ExtentReports extent;
        public ExtentTest Log;
        public ExtentHtmlReporter htmlReporter;
        
        private TestContext testContextInstance;
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        protected void GenerateExtentReports()
        {
            try
            {
                htmlReporter = new ExtentHtmlReporter(resultPath + "Testing.html");
            }
            catch (Exception e)
            {
               
            }
            if (!Directory.Exists(resultPath))
            {
                DirectoryInfo di = Directory.CreateDirectory(resultPath);
            }
            extent = new ExtentReports();

            extent.AttachReporter(htmlReporter);

            extent.AddSystemInfo("Operating System:", System.Environment.OSVersion.ToString());
            extent.AddSystemInfo("Machine Name:", System.Environment.MachineName);
            extent.AddSystemInfo("User Name:", System.Environment.UserName);
            extent.AddSystemInfo("Browser", "Internet Explore");

            string testName = TestContext.TestName;
            Log = extent.CreateTest(testName);           
        }

        protected void ExtentCleanUp()
        {
            extent.Flush();
        }

       
        public void LaunchBrowser(string browsertype)
        {
            if (browsertype.ToLower() == "chrome")
            {
                new WebDriverManager.DriverManager().SetUpDriver(new ChromeConfig());
                driver = new ChromeDriver();
            }
            else if (browsertype.ToLower() == "firefox")
            {
                new WebDriverManager.DriverManager().SetUpDriver(new FirefoxConfig());
                driver = new FirefoxDriver();
            }
            else
            {

            }

        }

    }
    
}
