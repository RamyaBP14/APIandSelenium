﻿using AventStack.ExtentReports;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestChatBot.Pages
{
   public class PurchaseFlight : BaseClass
    {
        private IWebElement PurchseFlight => driver.FindElement(By.XPath("//input[@type='submit']"));

        public void ClickonPurchseFlight(ExtentTest log)
        {
            PurchseFlight.Click();
        }
    }
}
