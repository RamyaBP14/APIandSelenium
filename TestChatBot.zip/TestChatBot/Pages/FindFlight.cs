﻿using AventStack.ExtentReports;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestChatBot.Pages
{
    public class FindFlight :BaseClass
    {
        private IWebElement departureCity => driver.FindElement(By.XPath("//select[@name='fromPort']"));
        private IWebElement destinationCity => driver.FindElement(By.XPath("//select[@name='toPort']"));
        private IWebElement findFlight => driver.FindElement(By.XPath("//input[@class='btn btn-primary']"));

        private IWebElement welcomeHeader => driver.FindElement(By.XPath("//h1"));

        public void SelectDepartureCity(string optionValue ,ExtentTest log)
        {
            departureCity.SelectFromComboBox(optionValue, log);
        }

        public void SelectDestinationCity(string optionValue, ExtentTest log)
        {
            destinationCity.SelectFromComboBox(optionValue, log);
        }

        public void ClickFindFlightButton( ExtentTest log)
        {
            findFlight.Click(log);

        }

        public string GetWelcomeText()
        {
            string welcomeText = welcomeHeader.Text;
            return welcomeText;
        }
    }
}
