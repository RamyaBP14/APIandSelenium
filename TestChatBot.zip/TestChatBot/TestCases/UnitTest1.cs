﻿using System.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestChatBot.Pages;
using static TestChatBot.Pages.FlightsMainScreen;

namespace TestChatBot
{
    [TestClass]
    public class UnitTest1 :BaseClass
    {
       
        [TestMethod]
        public void NewTest()
        {
            string deptCity = "Boston";
            string destCity = "London";
            string welcomeTextExpected = "Welcome to the Simple Travel Agency!";
            FindFlightPage.SelectDepartureCity(deptCity, Log);
            FindFlightPage.SelectDestinationCity(destCity, Log);
            string actualWelcomeText = FindFlightPage.GetWelcomeText();
            Log.LogVerificationResult("Verify welcome text ", welcomeTextExpected, actualWelcomeText);
            FindFlightPage.ClickFindFlightButton(Log);
            
            FlightsMainScreenPage.ChooseFlight("United Airlines", Log);

            PurchaseFlight purchaseFlight = new PurchaseFlight();
            purchaseFlight.ClickonPurchseFlight(Log);
            Confirmation confirmationPage = new Confirmation();
           string ConfirmedId= confirmationPage.GetConfirmationId();
            if (!string.IsNullOrEmpty(ConfirmedId))

            {
                Log.Pass("Flight booking confirmed and Id is" + ConfirmedId);
            }
            else
            {
                Log.Pass("Floght Not booked ");
            }

        }

        #region Additional Attributes
        [TestInitialize()]
        public void MyTestInitialize()
        {
            string browser = "chrome"; //ConfigurationManager.AppSettings["chrome"];
            string url = "https://blazedemo.com/";
            FlightsMainScreenPage.LaunchBrowser(browser);
            FlightsMainScreenPage.NavigateToURL(url);
            GenerateExtentReports();
        }

        [TestCleanup()]
        public void MyTestCleanup()
        {
            ExtentCleanUp();
            driver.Close();
        }
        #endregion
        #region class instantation 
        public FindFlight FindFlightPage
        {
            get
            {
                if (this.findFlight == null)
                {
                    this.findFlight = new FindFlight();
                }

                return this.findFlight;
            }
        }

        private FindFlight findFlight;

        public FlightsMainScreen FlightsMainScreenPage
        {
            get
            {
                if (this.mainScreen == null)
                {
                    this.mainScreen = new FlightsMainScreen();
                }

                return this.mainScreen;
            }
        }

        private FlightsMainScreen mainScreen;
        #endregion
    }
}
