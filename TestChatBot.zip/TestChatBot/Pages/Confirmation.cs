﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestChatBot.Pages
{
   public class Confirmation :BaseClass
    {
        public string GetConfirmationId()
        {
            var confirmationId = driver.FindElement(By.XPath("//table/tbody/tr[1]/td[2]")).Text;
            return confirmationId;

        }

    }
}
